package com.example.mobileprogrammingproject;

import static com.example.mobileprogrammingproject.R.id.recycle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class resturant extends AppCompatActivity {



    @Override



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resturant);


    }
}