package com.example.mobileprogrammingproject;

public class orders {
    String r1;
    String r2;

    String image2;

    public String getR1() {
        return r1;
    }

    public void setR1(String r1) {
        this.r1 = r1;
    }

    public String getR2() {
        return r2;
    }

    public void setR2(String r2) {
        this.r2 = r2;
    }



    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }



    public orders(String r1 , String r2,String image2) {
        this.r1 = r1;
        this.r2 = r2;

        this.image2 = image2;
    }
}
